READ ME

I have my demonstration in a main method in the 'Menu' class --> I found this extra class to be
the simplest and most organized way to demonstrate, so if you just run the class it should work. 
Originally I had the menu in the CourseList file, but it was a little disorganized, so having a 
seperate menu class should make it much easier to understand. 

My demonstration of this program uses an interactive menu so that the user has
full control over what they would like to do with the course list. By following
the instructions of the menu, the user should have full control over what they
want to do and demonstrate. Every function has an option in the menu. 

Additionally, most everything is bounds checked so there should not be problems if 
the user mistypes something or enters an invalid integer or something.

Have fun :)